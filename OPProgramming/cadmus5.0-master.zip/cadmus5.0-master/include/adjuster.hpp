#ifndef _ADJUSTER_H_
#define _ADJUSTER_H_

extern int d;

void adjustAsync();
void adjust();

void adjustTask(void* parameter);

void adjusterOp();

#endif
