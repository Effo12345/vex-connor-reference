#ifndef _LIFT_H_
#define _LIFT_H_

void lift(int vel);
void liftFast(int sp);
void liftSlow(int sp);
void liftOp();

#endif
