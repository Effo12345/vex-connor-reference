void newSkills();
void oldSkills();
