# 2011C-TT-Comp-Project
2011C Vex Tower Takeover competition project.

There are going to be a lot of issues and things that could have been done better. Trust me, I know better than anyone. Also, if youre here after searching on Github for vex competition code, I hope this will be a good tool for you to learn because they can be hard to find. 







Bring Back Bo3
